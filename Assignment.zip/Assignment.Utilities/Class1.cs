﻿using System;

namespace Ecommerce.Utilities
{
    public class Class1
    {
    }
}
